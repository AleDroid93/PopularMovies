package app.com.example.android.popularmovies;

import android.net.Uri;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Scanner;

/**
 * Created by Alessandro on 09/03/2017.
 */

public class NetworkUtils {

    public static String getResponseFromHTTPRequest(URL url) throws IOException{
        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
        String result = "";
        try{
            InputStream streamInput = connection.getInputStream();
            Scanner sc = new Scanner(streamInput);
            sc.useDelimiter("\\A");
            boolean hasNext = sc.hasNext();
            if(hasNext){
                return sc.next();
            }else{
                return null;
            }

        }finally{
            connection.disconnect();
        }
    }

    public static URL buildUrl(String urlString){
        Uri uri = Uri.parse(urlString).buildUpon()
                .build();
        URL url = null;
        try {
            url = new URL(uri.toString());
        }catch(MalformedURLException e){
            e.printStackTrace();
            return url;
        }
        return url;
    }
}
