package app.com.example.android.popularmovies;

import android.os.Parcelable;

/**
 * Created by Alessandro on 26/03/2017.
 */

public interface OnTaskCompleted {
    void onTaskInitialization();
    void onTaskCompleted(Parcelable[] s);
}
