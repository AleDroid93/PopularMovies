package app.com.example.android.popularmovies;

import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Parcelable;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import java.net.URL;
import java.util.ArrayList;

import butterknife.BindView;
import butterknife.ButterKnife;

public class MainActivity extends AppCompatActivity implements MovieAdapter.ListItemClickListener, OnTaskCompleted{
    private MovieAdapter mAdapter;
    @BindView(R.id.rv_movies) RecyclerView mRecyclerView;
    private final static String DB_POPULAR_MOVIES_URL = "https://api.themoviedb.org/3/movie/popular?api_key=[YOUR_API_KEY]";
    private final static String DB_TOP_RATED_MOVIES_URL = "https://api.themoviedb.org/3/movie/top_rated?api_key=[YOUR_API_KEY]";
    @BindView(R.id.error_message_text_view) TextView mErrorMessageTextView;
    @BindView(R.id.pb_loading_indicator) ProgressBar mLoadingIndicator;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ButterKnife.bind(this);
        // orientation layout problem handling
        if(getResources().getConfiguration().orientation == Configuration.ORIENTATION_PORTRAIT){
            mRecyclerView.setLayoutManager(new GridLayoutManager(this, 2));
        }
        else{
            mRecyclerView.setLayoutManager(new GridLayoutManager(this, 4));
        }
        mRecyclerView.setHasFixedSize(true);
        mAdapter = new MovieAdapter(100, this);
        mRecyclerView.setAdapter(mAdapter);
        //mLoadingIndicator.setVisibility(View.INVISIBLE);
        ActionBar actionBar = getSupportActionBar();
        actionBar.setBackgroundDrawable(new ColorDrawable(Color.BLACK));
        makeDbMoviesQuery(DB_POPULAR_MOVIES_URL);
    }

    @Override
    public void onListItemClick(Movie movieInfo) {
        Context context = this;
        Class destinationClass = MovieDetailsActivity.class;
        Intent intentToStartDetailActivity = new Intent(context, destinationClass);
        ArrayList<String> extras = new ArrayList<>();
        extras.add(movieInfo.getOriginalTitle());
        extras.add(movieInfo.getPlotSynopsis());
        extras.add(movieInfo.getReleaseDate());
        String urlPoster = "http://image.tmdb.org/t/p/w342" + movieInfo.getUrlMoviePoster();
        extras.add(urlPoster);
        extras.add(movieInfo.getUsrRating());
        intentToStartDetailActivity.putStringArrayListExtra(Intent.EXTRA_TEXT, extras);
        startActivity(intentToStartDetailActivity);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu){
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.movie_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsMenuSelected(MenuItem item){
        return onOptionsItemSelected(item);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item){
        int idAction = item.getItemId();
        switch(idAction){
            case R.id.menu_item1:
                // refreshing
                mAdapter.setMoviesData(null);
                // update
                makeDbMoviesQuery(DB_TOP_RATED_MOVIES_URL);
                break;
            case R.id.menu_item2:
                // refreshing
                mAdapter.setMoviesData(null);
                // update
                makeDbMoviesQuery(DB_POPULAR_MOVIES_URL);
                break;
            default:
                Toast.makeText(this, "ops!", Toast.LENGTH_SHORT).show();

        }
        return super.onOptionsItemSelected(item);
    }


    public void makeDbMoviesQuery(String url){
        //new MoviesAsyncTask(this).execute(url);
        MovieVolleyRequestActivity req = new MovieVolleyRequestActivity(this, url);
    }

    private void showJsonResults(){
        mErrorMessageTextView.setVisibility(View.INVISIBLE);
    }

    private void showErrorMessage(){
        mErrorMessageTextView.setVisibility(View.VISIBLE);
    }

    @Override
    public void onTaskInitialization() {
        mLoadingIndicator.setVisibility(View.VISIBLE);
    }

    @Override
    public void onTaskCompleted(Parcelable[] s) {
        if(s != null){
            showJsonResults();
            mAdapter.setMoviesData((Movie[])s);
        }else
            showErrorMessage();
        mLoadingIndicator.setVisibility(View.INVISIBLE);
    }

}
