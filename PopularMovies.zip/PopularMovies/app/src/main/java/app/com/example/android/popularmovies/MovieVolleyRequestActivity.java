package app.com.example.android.popularmovies;

import android.content.Context;
import android.support.v7.app.AppCompatActivity;

import com.android.volley.*;
import com.android.volley.toolbox.*;

import org.json.JSONException;

/**
 * Created by Alessandro on 27/03/2017.
 */

public class MovieVolleyRequestActivity {
    private Context mContext;
    private RequestQueue queue;
    private String mUrl;
    private Movie[] moviesData;
    private OnTaskCompleted mListener;

    public MovieVolleyRequestActivity(final OnTaskCompleted listener, String url) {
        mContext = (Context)listener;
        queue = Volley.newRequestQueue(mContext);
        mUrl = url;
        moviesData = null;
        mListener = listener;
        StringRequest stringRequest = new StringRequest(Request.Method.GET, mUrl,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            moviesData = MovieDetailsUtils.getMovieInfoFromJsonString(mContext, response);
                            mListener.onTaskCompleted(moviesData);
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                mListener.onTaskCompleted(moviesData);
            }
        });

        // Add the request to the RequestQueue.
        queue.add(stringRequest);
    }
}
