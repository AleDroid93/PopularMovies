package app.com.example.android.popularmovies;

import android.content.Context;
import android.os.AsyncTask;
import android.os.Parcelable;

import java.net.URL;

/**
 * Created by Alessandro on 26/03/2017.
 */

class MoviesAsyncTask extends AsyncTask<String, Void, Movie[]> {

    private OnTaskCompleted mListener;


    public MoviesAsyncTask(OnTaskCompleted listener){
        mListener = listener;
    }

    @Override
    protected void onPreExecute() {
        super.onPreExecute();
        mListener.onTaskInitialization();
    }

    @Override
    protected Movie[] doInBackground(String... params) {
        String searchUrl = params[0];
        String dbMoviesResultString = null;
        Movie[] posterStrings = null;
        URL url = NetworkUtils.buildUrl(searchUrl);
        try{
            dbMoviesResultString = NetworkUtils.getResponseFromHTTPRequest(url);
            posterStrings = MovieDetailsUtils.getMovieInfoFromJsonString((Context)mListener, dbMoviesResultString);
        }catch(Exception e){
            e.printStackTrace();
        }
        return posterStrings;
    }

    @Override
    protected void onPostExecute(Movie[] s){
        mListener.onTaskCompleted(s);
    }
}
