package app.com.example.android.popularmovies;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;

import butterknife.BindView;
import butterknife.ButterKnife;

public class MovieDetailsActivity extends AppCompatActivity {

    private ArrayList<String> mMovieInfo;
    @BindView(R.id.tv_display_movie_title) TextView mMovieTitle;
    @BindView(R.id.tv_display_movie_date) TextView mReleaseDate;
    @BindView(R.id.tv_display_movie_rating) TextView mUserRating;
    @BindView(R.id.tv_display_movie_plot) TextView mPlotSynapsis;
    @BindView(R.id.tv_display_movie_poster) ImageView mMoviePoster;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_movie_details);
        ButterKnife.bind(this);
        Intent intent = getIntent();
        if(intent != null) {
            if (intent.hasExtra(Intent.EXTRA_TEXT)) {
                mMovieInfo = intent.getStringArrayListExtra(Intent.EXTRA_TEXT);
                mMovieTitle.setText(mMovieInfo.get(0));
                Picasso.with(this).load(mMovieInfo.get(3)).into(mMoviePoster);
                mUserRating.setText(mMovieInfo.get(4)+"/10");
                mReleaseDate.setText(mMovieInfo.get(2));
                mPlotSynapsis.setText(mMovieInfo.get(1));
            }
        }
    }
}
