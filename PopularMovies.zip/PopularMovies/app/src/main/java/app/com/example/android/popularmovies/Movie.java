package app.com.example.android.popularmovies;

import android.os.Parcel;
import android.os.Parcelable;

import java.lang.reflect.ParameterizedType;

/**
 * Created by Alessandro on 18/03/2017.
 */

public class Movie implements Parcelable{
    private String originalTitle;
    private String usrRating;
    private String urlMoviePoster;
    private String plotSynopsis;
    private String releaseDate;

    public Movie(String title, String rating, String urlPoster, String plot, String date){
        originalTitle = title;
        usrRating = rating;
        urlMoviePoster = urlPoster;
        plotSynopsis = plot;
        releaseDate = date;
    }

    protected Movie(Parcel in) {
        originalTitle = in.readString();
        usrRating = in.readString();
        urlMoviePoster = in.readString();
        plotSynopsis = in.readString();
        releaseDate = in.readString();
    }

    public static final Creator<Movie> CREATOR = new Creator<Movie>() {
        @Override
        public Movie createFromParcel(Parcel in) {
            return new Movie(in);
        }

        @Override
        public Movie[] newArray(int size) {
            return new Movie[size];
        }
    };

    public String getOriginalTitle() {
        return originalTitle;
    }

    public String getUsrRating() {
        return usrRating;
    }

    public String getUrlMoviePoster() {
        return urlMoviePoster;
    }

    public String getReleaseDate() {
        return releaseDate;
    }

    public String getPlotSynopsis() {
        return plotSynopsis;
    }

    public void setOriginalTitle(String originalTitle) {
        this.originalTitle = originalTitle;
    }

    public void setUsrRating(String usrRating) {
        this.usrRating = usrRating;
    }

    public void setUrlMoviePoster(String urlMoviePoster) {
        this.urlMoviePoster = urlMoviePoster;
    }

    public void setPlotSynopsis(String plotSynopsis) {
        this.plotSynopsis = plotSynopsis;
    }

    public void setReleaseDate(String releaseDate) {
        this.releaseDate = releaseDate;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(originalTitle);
        parcel.writeString(releaseDate);
        parcel.writeString(usrRating);
        parcel.writeString(plotSynopsis);
        parcel.writeString(urlMoviePoster);
    }
}
