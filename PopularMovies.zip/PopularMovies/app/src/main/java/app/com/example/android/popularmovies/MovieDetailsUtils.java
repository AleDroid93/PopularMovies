package app.com.example.android.popularmovies;

import android.content.Context;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/**
 * Created by Alessandro on 09/03/2017.
 */

public final class MovieDetailsUtils {
    private final static String POSTER_LABEL = "poster_path";
    private final static String ORIGINAL_TITLE_LABEL = "original_title";
    private final static String PLOT_SYNOPSIS_LABEL = "overview";
    private final static String RELEASE_DATE_LABEL = "release_date";
    private final static String USER_RATING_LABEL = "vote_average";

    public static Movie[] getMovieInfoFromJsonString(Context context, String movieJsonString)throws JSONException {
        JSONObject jsonObject = new JSONObject(movieJsonString);
        JSONArray jsonPosters = jsonObject.getJSONArray("results");
        Movie[] posterStrings = new Movie[jsonPosters.length()];

        for (int i = 0; i < jsonPosters.length(); i++) {
            JSONObject movieInfo = jsonPosters.getJSONObject(i);
            String moviePoster = movieInfo.getString(POSTER_LABEL);
            String title = movieInfo.getString(ORIGINAL_TITLE_LABEL);
            String date = movieInfo.getString(RELEASE_DATE_LABEL);
            String plot = movieInfo.getString(PLOT_SYNOPSIS_LABEL);
            String rating = movieInfo.getString(USER_RATING_LABEL);

            Movie movie = new Movie(title, rating, moviePoster, plot, date);
            posterStrings[i] = movie;
        }
        return posterStrings;
    }
}
