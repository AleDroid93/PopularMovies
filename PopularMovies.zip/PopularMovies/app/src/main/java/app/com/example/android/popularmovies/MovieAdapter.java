package app.com.example.android.popularmovies;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.squareup.picasso.Picasso;

/**
 * Created by Alessandro on 02/03/2017.
 */

public class MovieAdapter extends RecyclerView.Adapter<MovieAdapter.MovieViewHolder> {

    interface ListItemClickListener{
        void onListItemClick(Movie MovieInfo);
        boolean onOptionsMenuSelected(MenuItem item);
    }

    class MovieViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener{

        private ImageView mImageView;
        private Context context;

        public MovieViewHolder(Context context, View itemView) {
            super(itemView);
            this.context = context;
            mImageView = (ImageView) itemView.findViewById(R.id.img_movie_poster);
            itemView.setOnClickListener(this);
        }

        private void bind(String urlImage) {
            Picasso.with(context).load(urlImage).into(mImageView);
        }

        @Override
        public void onClick(View view) {
            int clickedPos = getAdapterPosition();
            Movie movie = moviesData[clickedPos];
            mClickItemListener.onListItemClick(movie);
        }
    }

    Movie[] moviesData;
    private final ListItemClickListener mClickItemListener;


    public MovieAdapter(int mNumberItems, ListItemClickListener listener){
        mClickItemListener = listener;
    }

    @Override
    public MovieViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        Context context = parent.getContext();
        int layoutIdForListItem = R.layout.movies_list_item;
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(layoutIdForListItem, parent, false);
        MovieViewHolder viewHolder = new MovieViewHolder(context, view);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(MovieViewHolder holder, int position) {
        String urlImage = "http://image.tmdb.org/t/p/w342" + moviesData[position].getUrlMoviePoster();
        holder.bind(urlImage);
    }


    @Override
    public int getItemCount() {
        if(moviesData ==  null)
            return 0;
        return moviesData.length;
    }


    public void setMoviesData(Movie[] movies){
        moviesData = movies;
        notifyDataSetChanged();
    }


}
